package com.mtd.ecommerce_app.enums;

public enum OrderStatus {
	pending,
    shipped,
    delivered,
    cancelled
}
