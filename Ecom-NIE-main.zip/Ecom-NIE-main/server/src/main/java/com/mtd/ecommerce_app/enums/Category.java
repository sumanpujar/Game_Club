package com.mtd.ecommerce_app.enums;

public enum Category {
	ELECTRONICS,
    FURNITURE,
    HOME,
    FASHION
}
